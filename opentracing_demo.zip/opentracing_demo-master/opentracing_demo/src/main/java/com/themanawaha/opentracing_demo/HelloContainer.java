package com.themanawaha.opentracing_demo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/hello")
public class HelloContainer {
private static final Logger logger = LoggerFactory.getLogger(HelloContainer.class);
    
private RestTemplate restTemplate;
@Value("${spring.application.name}")
    private String applicationName;
public HelloContainer(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }
@GetMapping("/path1")
    public ResponseEntity<String>  path1() {
logger.info("Incoming request at {} for request /path1 ", applicationName);
        String response = restTemplate.getForObject("http://localhost:8080/hello/path2", String.class);
        return ResponseEntity.ok("response from /path1 + " + response);
    }
@GetMapping("/path2")
    public ResponseEntity<String>  path2() {
        logger.info("Incoming request at {} at /path2", applicationName);
        return ResponseEntity.ok("response from /path2 ");
    }
@RequestMapping("/hello")
public String hello() {
    return "Hello World!";
}

@RequestMapping("/docker")
public String docker() {
    return "Hello Docker!";
}

@RequestMapping("/spring")
public String spring() {
    return "Hello Spring!";
}

@RequestMapping("/")
public String index() {
    return "Welcome to this little demo application. Feel free to try the other pages.";
}
}
