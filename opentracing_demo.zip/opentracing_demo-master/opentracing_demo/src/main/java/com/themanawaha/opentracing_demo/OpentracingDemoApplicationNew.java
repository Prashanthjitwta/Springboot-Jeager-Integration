package com.themanawaha.opentracing_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import io.jaegertracing.Configuration;

@SpringBootApplication
public class OpentracingDemoApplicationNew {

	@Bean
	public io.opentracing.Tracer jaegerTracer() {

		Configuration config = Configuration.fromEnv();

		System.out.println("Config_Host: " + config.getReporter().getSenderConfiguration().getAgentHost());
		System.out.println("Config_Port: " + config.getReporter().getSenderConfiguration().getAgentPort());
		System.out.println("Sampler_Host_Port: " + config.getSampler().getManagerHostPort());

		return config.getTracer();
	}
	
	@Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
       return builder.build();
    }

	public static void main(String[] args) {
		SpringApplication.run(OpentracingDemoApplicationNew.class, args);
	}
}